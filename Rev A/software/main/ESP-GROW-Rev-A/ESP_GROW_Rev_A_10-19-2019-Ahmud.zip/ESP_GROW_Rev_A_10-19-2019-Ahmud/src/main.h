#ifndef MAIN_H

//char* product = "Cookies";
char* product = "Humm House";
char* revision = "10/19/2019";

//setpoint for waterpump to turn on
int soilsetpoint = 35;

//Humm House Soil Sensor mapping scale measured when soil wet
int sensmap_dry = 930;
int sensmap_wet = 660;

// Wifi Details
//const char* ssid = "Pretty Fly For A Wifi-2.4";
//const char* password = "supercarbon";

const char* ssid = "HUMMHQ";
const char* password = "humm1992";

#endif