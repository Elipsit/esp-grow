#ifndef MAIN_H

char* product = "Cookies";
char* revision = "9/8/2019";

//setpoint for waterpump to turn on
int soilsetpoint = 35;

// Wifi Details
const char* ssid = "Pretty Fly For A Wifi-2.4";
const char* password = "supercarbon";

//const char* ssid = "Elipsit-V30";
//const char* password = "Rodrigues";

//const char* ssid = "ologic";
//const char* password = "r0b0tinmyh3ad";

//Cookies Soil Sensor mapping scale measured when soil wet
//int sensmap_dry = 920;
//int sensmap_wet = 780;

//Fire OG Soil Sensor mapping scale measured when soil wet
int sensmap_dry = 920;
int sensmap_wet = 840;

#endif