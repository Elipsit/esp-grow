#ifndef Arduino

void pushJSON_to_Firebase();
void Init_Firebase();
#endif