#ifndef MAIN_H

//Project Defaults
const char* product = "TrainWreck";
const char* revision = "2/6/2020";



// Wifi Details
const char* ssid = "tegridyfarms-2.4";
const char* password = "supercarbon";

//const char* ssid = "Elipsit-V30";
//const char* password = "Rodrigues";

//const char* ssid = "ologic";
//const char* password = "r0b0tinmyh3ad";



#endif